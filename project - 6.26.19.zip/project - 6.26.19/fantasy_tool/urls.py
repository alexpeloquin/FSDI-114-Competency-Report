from django.urls import path
from fantasy_tool import views

urlpatterns = [
    path("", views.fantasy_tool, name="fantasy_tool"),
    path("batters", views.fantasy_batters, name="fantasy_batters"),
    path("pitchers", views.fantasy_pitchers, name="fantasy_pitchers"),
    path("about", views.about, name="about"),
    path("blog", views.blog, name="blog"),
]

